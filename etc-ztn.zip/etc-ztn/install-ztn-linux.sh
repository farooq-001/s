#!/bin/bash
PKG_PATH=/opt/install
APP_PATH=/opt/blusapphire
LOG_PATH=/var/log
LOG_FILE=install-ztn.log

OPT_PATH=/opt
ZTN_PATH=/opt/ztn
ZTN_PACKAGE=ztn-linux.tar.gz

CUSTOMER_CODE=$1
DEVICE_CODE=$2
PWD=`pwd`

exec > >(tee -i $LOG_PATH/$LOG_FILE)
exec 2>&1

if [ "$USER" != "root" ]; then
    echo ""
    echo 'Invalid User!!! Please login as root and rerun the script.'
    echo ""
    exit 0
fi

echo -n "Checking for Internet access..."
IP=$(curl -s ipinfo.io/ip 2> /dev/null)
if [[ $? -eq 0 ]]; then
    echo " Online."
    echo ""
else
    echo " Offline."
    echo ""
    echo "Check internet access and rerun script. Terminating Script!"
    exit 1
fi

if [ $# -ne 2 ]; then
  echo "Usage: install-ztn-linux <customer_code> <device_code>"
  exit 1
fi

if [ ! -f "$APP_PATH/.sysprep" ] ; then
    echo ""
    echo 'Please run sysprep.sh before running this script!'
    echo ""
    exit 0
fi 

echo "Customer Code: $CUSTOMER_CODE"
echo "Device Code: $DEVICE_CODE"

mkdir -p $PKG_PATH/certs

if [ ! -f "$APP_PATH/.ztn-installed" ] ; then
    echo "Setting up ZTN..."
    echo ""
    echo "Downloading ZTN package..."
    curl -o $PKG_PATH/$ZTN_PACKAGE https://prod1-us.blusapphire.net/export/install/ztn/$ZTN_PACKAGE
    curl -o $PKG_PATH/$ZTN_PACKAGE.md5 https://prod1-us.blusapphire.net/export/install/ztn/$ZTN_PACKAGE.md5

    echo -n "Checking MD5 for the downloaded package..."
    cd $PKG_PATH
    if md5sum --status -c $PKG_PATH/$ZTN_PACKAGE.md5; then
        echo "OK"
        echo ""
        echo -n "Extracting ZTN package..."
        tar -xf $PKG_PATH/$ZTN_PACKAGE -C $OPT_PATH
        echo "Done."
        echo ""
        echo "Downloading certificate..."
        curl -o $PKG_PATH/certs/$DEVICE_CODE.tar.gz https://prod1-us.blusapphire.net/export/$CUSTOMER_CODE/ztn-certs/$DEVICE_CODE.tar.gz
        curl -o $PKG_PATH/certs/$DEVICE_CODE.tar.gz.md5 https://prod1-us.blusapphire.net/export/$CUSTOMER_CODE/ztn-certs/$DEVICE_CODE.tar.gz.md5
        echo -n "Checking MD5 for the downloaded package..."
        cd $PKG_PATH/certs
        if md5sum --status -c $PKG_PATH/certs/$DEVICE_CODE.tar.gz.md5; then
            echo "OK"
            echo ""
            echo -n "Extracting Certificate..."
            tar -xf $PKG_PATH/certs/$DEVICE_CODE.tar.gz -C $ZTN_PATH
            echo "Done."
            chown -R $BLU_USER.$BLU_USER $ZTN_PATH
            rm -f /etc/ztn
            ln -s $ZTN_PATH/$DEVICE_CODE /etc/ztn
            cp $ZTN_PATH/ztn.service /etc/systemd/system/
            echo ""
            echo "Enabling ZTN..." 
            systemctl enable ztn
            echo "Starting ZTN..."
            systemctl start ztn
            systemctl status ztn
            touch $APP_PATH/.ztn-installed
        else
            echo "Failed!"
            exit 0
        fi
    else
        echo "Failed!"
        exit 0
    fi
else
    echo "ZTN already installed!"
    exit 0
fi

cd $PWD
echo ""
echo "ZTN setup completed."
echo ""
